<?php

require_once('funciones.php');

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {

    protected $_config;
    static $_instances = array();
    static protected $_logger = null;
    static protected $_writer = null;
    static protected $_profiler = array();
    static protected $_start_profiler = null;
    static $_testing = false;
    static $_installed = false;

    const MAX_LOG_SIZE = 1310720;

    protected function _initProfiler() {
        Bootstrap::profileStart('Bootstrap');
    }

    protected function _initAutoload() {
        Bootstrap::profileStart('_initAutoload');

        $autoloader = new Zend_Application_Module_Autoloader(array(
            'namespace' => 'Front_',
            'basePath' => APPLICATION_PATH . '/front',
        ));
        $autoloader = new Zend_Application_Module_Autoloader(array(
            'namespace' => 'Back_',
            'basePath' => APPLICATION_PATH . '/back',
        ));
        $autoloader = new Zend_Application_Module_Autoloader(array(
            'namespace' => '',
            'basePath' => APPLICATION_PATH . '/',
        ));
        $autoloader->addResourceTypes(array(
            'menu' => array(
                'namespace' => 'Menu',
                'path' => 'menus',
        )));

        $autoloader->addResourceTypes(array(
            'exception' => array(
                'namespace' => 'Exception',
                'path' => 'exceptions',
        )));

        Bootstrap::profileEnd('_initAutoload');
    }

    protected function _initActionHelpers() {
        Bootstrap::profileStart('_initActionHelpers');

        Zend_Controller_Action_HelperBroker::addPath(APPLICATION_PATH . '/back/helpers');
        Zend_Controller_Action_HelperBroker::addPath(APPLICATION_PATH . '/front/helpers');

        Bootstrap::profileEnd('_initActionHelpers');
    }

    protected function _initControllers() {
        Bootstrap::profileStart('_initControllers');

        $this->bootstrap('FrontController');
        $ctrl = $this->getResource('FrontController');
        $ctrl->setParam('disableOutputBuffering', true);
        $ctrl->setControllerDirectory(array(
            'default' => APPLICATION_PATH . '/front/ctrl',
            'back' => APPLICATION_PATH . '/back/ctrl',
        ));
        /**
         * Manejo de errores
         */
        $ctrl->registerPlugin(new Plugin_Setup());
        $ctrl->registerPlugin(new Plugin_Cache());
        $ctrl->registerPlugin(new Zend_Controller_Plugin_ErrorHandler(array(
            'module' => 'default',
            'controller' => 'error',
            'action' => 'error'
        )));
        $ctrl->registerPlugin(new Plugin_ErrorSelector());
        $ctrl->registerPlugin(new Plugin_AclBack());

        $writer = new Zend_Log_Writer_Firebug();
        $logger = new Zend_Log($writer);
        Zend_Registry::set('logger', $logger);

        Bootstrap::profileEnd('_initControllers');
    }

    protected function _initConfig() {
        Bootstrap::profileStart('_initConfig');
        try {
            $opts = $this->getApplication()->getOptions();
            if (isset($opts['resources']) && isset($opts['resources']['session'])) {
                Zend_Session::setOptions($opts['resources']['session']);
            }
        } catch (Exception $e) {
            
        }
        Bootstrap::setTesting($opts['bootstrap']['testing']);

        /**
         * Config
         */
        Zend_Registry::set('Zend_Config', $opts);

        Bootstrap::profileEnd('_initConfig');
    }

    protected function _initDB() {
        Bootstrap::profileStart('_initDB');

        /**
         * Base de datos
         */
        $rsc = $this->getOption('resources');
        if (isset($rsc['db'])) {
            $dbAdapter = Zend_Db::factory($rsc['db']['adapter'], $rsc['db']['params']);

            $profiler = new Zend_Db_Profiler_Firebug('Consultas realizadas');
            $profiler->setEnabled($rsc['db']['log']);

            $dbAdapter->setProfiler($profiler);

            $dbAdapter->query("SET NAMES 'utf8'");

            Zend_Db_Table_Abstract::setDefaultAdapter($dbAdapter);

            $cache = $this->getOption('cache');
            $cache = Zend_Cache::factory('Core', 'File', $cache['frontopt'], $cache['backopt']);
            Zend_Db_Table_Abstract::setDefaultMetadataCache($cache);
        }

        Bootstrap::profileEnd('_initDB');
    }

    protected function _initAcl() {
        Bootstrap::profileStart('_initAcl');

        $acl = new Zend_Acl();

        $acl->add(new Zend_Acl_Resource('front'));
        $acl->add(new Zend_Acl_Resource('back'));

        foreach (self::getSingleton('Model_Roles')->fetchAll() as $role) {
            $acl->addRole($role->getNombre());
            $acl->allow($role->getNombre(), 'front');
            $acl->allow($role->getNombre(), 'back', array('error'));
            foreach ($role->getPermisos() as $permiso) {
                $acl->allow($role->getNombre(), 'back', $permiso->getCode());
            }
        }
        $acl->allow('admin', 'back', array('dashboard', 'salir'));

        Zend_Registry::set('Zend_Acl', $acl);
        Bootstrap::profileEnd('_initAcl');
    }

    protected function _initLocale() {
        Bootstrap::profileStart('_initLocale');

        $tr = new Zend_Translate(
                'csv', APPLICATION_PATH . '/data/langs/', null, array(
            'scan' => Zend_Translate::LOCALE_DIRECTORY,
//                            'log' => self::getLogger('-traduccion'),
//                            'logUntranslated' => true,
            'disableNotices' => true,
                )
        );
        Zend_Registry::set('Zend_Translate', $tr);
        Bootstrap::profileEnd('_initLocale');
    }

    protected function _initRouters() {
        Bootstrap::profileStart('_initRouters');

        $ctrl = $this->getResource('FrontController');
        $router = $ctrl->getRouter();

        $router->addRoute('default', new Zend_Controller_Router_Route(
                ':locale/:@controller/:@action/*', array(
            'controller' => 'index',
            'action' => 'index',
            'locale' => APPLICATION_LANG
        )));

        $router->addRoute('tipos-de-masaje', new Zend_Controller_Router_Route(
                ':locale/@tipos-de-masaje', array(
            'controller' => 'index',
            'action' => 'tipos-de-masaje',
            'locale' => APPLICATION_LANG
        )));

        $router->addRoute('terapeutas', new Zend_Controller_Router_Route(
                ':locale/@terapeutas', array(
            'controller' => 'index',
            'action' => 'terapeutas',
            'locale' => APPLICATION_LANG
        )));

        $router->addRoute('precios', new Zend_Controller_Router_Route(
                ':locale/@precios', array(
            'controller' => 'index',
            'action' => 'precios',
            'locale' => APPLICATION_LANG
        )));
        
        $router->addRoute('regalar', new Zend_Controller_Router_Route(
                ':locale/@regalar', array(
            'controller' => 'index',
            'action' => 'regalar',
            'locale' => APPLICATION_LANG
        )));

        $router->addRoute('contacto', new Zend_Controller_Router_Route(
                ':locale/@contacto', array(
            'controller' => 'legales',
            'action' => 'contacto',
            'locale' => APPLICATION_LANG
        )));

        $router->addRoute('back', new Zend_Controller_Router_Route(
                'back/:locale/:@controller/:@action/*', array(
            'module' => 'back',
            'controller' => 'index',
            'action' => 'index',
            'locale' => APPLICATION_LANG
        )));

        $uri = new Zend_Controller_Request_Http();
//        $idioma = $router->route($uri)->getParam('locale');
        $idioma = APPLICATION_LANG;
//        $idioma = ($idioma) ? $idioma : APPLICATION_LANG;

        if (Zend_Locale::isLocale($idioma)) {
            $adp = Zend_Registry::get('Zend_Translate')->getAdapter();
            $adp->setLocale($idioma);
            Zend_Locale::setDefault($idioma);
            Zend_Registry::set('Zend_Locale', new Zend_Locale($idioma));
            $router->setGlobalParam('locale', $idioma);
        }

        Bootstrap::profileEnd('_initRouters');
    }

    protected function _initViewHelpers() {
        Bootstrap::profileStart('_initViewHelpers');

        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->addHelperPath(APPLICATION_PATH . '/front/views/helpers', '');
        $view->headTitle()->enableTranslation();
        $view->assign('locale', Zend_Registry::get('Zend_Translate')->getLocale());
        $viewRenderer = new Zend_Controller_Action_Helper_ViewRenderer();
        $viewRenderer->setView($view);

        $view->addFilterPath(APPLICATION_PATH . '/front/views/filters', 'Zend_View_Filter');
        $view->addFilter('Tidy');

        Zend_Controller_Action_HelperBroker::addHelper($viewRenderer);

        Bootstrap::profileEnd('_initViewHelpers');
    }

    protected function _initDoctype() {
        Bootstrap::profileStart('_initDoctype');

        $view = $this->getResource('view');
        $view->doctype('XHTML1_STRICT');

        Bootstrap::profileEnd('_initDoctype');
    }

    static function getLocales() {
        return array(
            'es' => 'Espanol',
            'en' => 'Ingles',
        );
    }

    static function getSingleton($class) {
        if (!isset(self::$_instances[$class])) {
            if (!class_exists($class))
                throw new Exception(__('La clase %s no existe', $class));
            self::$_instances[$class] = new $class();
        }

        return self::$_instances[$class];
    }

    static function getServicios() {
        return array(
            array(
                'codigo' => 'diseno',
                'titulo' => 'Diseno web',
                'icono' => 'wid-pc.png',
                'descripcion' => 'En Baillyweb no vemos tu pagina web como otra ' .
                'herramienta de marketing, la vemos como un miembro de tus equipos ' .
                'de Ventas, Marketing y Tecnologias.',
            ),
            array(
                'codigo' => 'bases-de-datos',
                'titulo' => 'Bases de datos',
                'icono' => 'wid-herramientas.png',
                'descripcion' => 'La implementacion de bases de datos en paginas ' .
                'web, le da al cliente la libertad total para publicar y editar el ' .
                'contenido de su pagina web sin necesidad de conocimientos de ' .
                'programacion.',
            ),
            array(
                'codigo' => 'posicionamiento-en-buscadores',
                'titulo' => 'Posicionamiento web',
                'icono' => 'wid-barras.png',
                'descripcion' => 'Tenemos mucha experiencia en posicionar paginas ' .
                'web en buscadores ( como Google, Yahoo y MSN)  y podemos ayudarlo a que su negocio tambien lo este.',
            ),
            array(
                'codigo' => 'e-commerce',
                'titulo' => 'e-commerce',
                'icono' => 'wid-cart.png',
                'descripcion' => 'Anualmente hacemos 2 paginas web gratias para proyectos solidarios.',
            ),
            array(
                'codigo' => 'identidad-corporativa',
                'titulo' => 'Identidad corporativa',
                'icono' => 'wid-pinceles.png',
                'descripcion' => 'Cuando alguien menciona a coca-cola o Pepsi, ' .
                'automaticamente visualizamos el logo, el slogan y puede ser que ' .
                'hasta la cancion de la publicidad.',
            ),
            array(
                'codigo' => 'newsletter',
                'titulo' => 'Newsletter',
                'icono' => 'wid-news.png',
                'descripcion' => 'Para una publicidad directa hacia sus clientes, ' .
                'el Marketing por email puede ser una herramienta muy efectiva ' .
                'para su negocio.',
            ),
            array(
                'codigo' => 'cds-dvds-interactivos',
                'titulo' => "CD's - DVD's Interactivos ",
                'icono' => 'wid-optico.png',
                'descripcion' => 'Parte de nuestro equipo tiene mucha experiencia ' .
                'en el mundo audiovisual y podemos ofrecer soluciones de medios ' .
                'audiovisuales a nuestros clientes a un precio competitivo',
            ),
        );
    }

    static function profileStart($id, $msg = '') {
        if (is_array($msg) || is_object($msg)) {
            $msg = Zend_Debug::dump($msg, null, false);
            $except = 'Exception';
        } else {
            $except = $msg;
        }

        try {
            throw new Exception($msg);
        } catch (Exception $e) {
            $e = $e->getTrace();
        }
        if (self::$_start_profiler === null) {
            self::$_start_profiler = microtime(true);
        }
        self::$_profiler[$id][] = array('trace' => $e, 'msg' => $msg);
        return self::$_profiler;
    }

    static function profileStatic($id, $msg = '') {
        if (is_array($msg) || is_object($msg)) {
            $msg = Zend_Debug::dump($msg, null, false);
        }

        try {
            throw new Exception($msg);
        } catch (Exception $e) {
            $e = $e->getTrace();
        }
        self::$_profiler[$id][] = array('trace' => $e, 'msg' => $msg, 'tiempo' => 0);
        return self::$_profiler;
    }

    static function profileEnd($id) {
        if (self::$_start_profiler === null) {
            throw new Exception('Imposible finalizar el profiler sin antes haberlo iniciado');
        } else {
            if (isset(self::$_profiler[$id])) {
                self::$_profiler[$id][count(self::$_profiler[$id]) - 1]['tiempo'] = microtime(true) - self::$_start_profiler;
                return self::$_profiler;
            }
        }
        throw new Exception(sprintf('Se intenta finalizar una id inexsistente: "%s"', $id));
    }

    static function getProfile() {
        return self::$_profiler;
    }

    static function isDebug() {
        $sess = new Zend_Session_Namespace('front');
        return ((bool) $sess->debug && self::isTesting());
    }

    static function isTesting() {
        return self::$_testing;
    }

    static function logException(Exception $e, $prioridad = Zend_Log::WARN) {
        $msj = $e->getMessage() . PHP_EOL . $e->getTraceAsString() . PHP_EOL;
        self::log($msj, $prioridad, '-exception');
    }

    static function log($msj, $prioridad = Zend_Log::WARN, $prefix = '') {
        $_logger = self::getLogger($prefix);
        $_logger->log($msj, $prioridad);

        self::mail($msj, $prioridad);
    }

    static function getLogger($prefix = '') {
        if (!self::$_logger instanceof Zend_Log_Writer) {
            $tmp = $arc = DATA_PATH . '/logs/bootstrap' . $prefix . date('-Ymd');
            $i = 0;
            while (is_file($tmp . '.log') && filesize($tmp . '.log') > self::MAX_LOG_SIZE) {
                $tmp = $arc . '-' . ((string) ++$i);
            }
            $arc = $tmp . '.log';
            self::$_writer = new Zend_Log_Writer_Stream($arc);
            self::$_logger = new Zend_Log(self::$_writer);
        }
        return self::$_logger;
    }

    static function mail($msj, $prioridad) {
        if ($prioridad <= 3) {
            try {
                $msj .= PHP_EOL . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . PHP_EOL;
                $mail = new Service_Mail();
                $mail->setSubject('[Zimbra Panel] Error')
                        ->setTo('manuelcanepa@gmail.com', 'Manuel Canepa')
                        ->setId(Service_Mail::TIPO_ERROR)
                        ->setBodyText($msj)
                        ->send();
            } catch (Exception $e) {
                self::logException($e);
            }
        }
    }

    static function logVar($var) {
        self::log(var_export($var, true), Zend_Log::WARN, '-vars');
    }

    static function setTesting($test) {
        self::$_testing = $test;
    }

    static function getNombreSitio() {
        return 'React';
    }

    public function run() {
        parent::run();
        Bootstrap::profileEnd('Bootstrap');
    }

}
