<?php

class Model_Row_Usuario extends Model_Row_Abstract {

    private $_rol = null;
    private $_tipos_masajes = null;

    public function getRole() {
        if ($this->_rol === null && $this->rol_id !== null) {
            $this->_rol = $this->findParentRow('Model_Roles');
        }
        return $this->_rol;
    }

    /**
     *
     * @return Model_Row_Distrito
     */
    public function getDistrito() {
        $key = 'distrito';
        if (!$distrito = $this->getCache($key)) {
            $distrito = $this->findParentRow('Model_Distritos');
            $this->setCache($key, $distrito);
        }
        return $distrito;
    }

    public function getTiposMasajes() {
        if ($this->_tipos_masajes === null) {
            $this->_tipos_masajes = $this->findManyToManyRowset('Model_TiposMasajes', 'Model_UsuariosTiposMasajes');
        }
        return $this->_tipos_masajes;
    }

    public function getExperiencia() {
        return $this->sobre_mi;
    }

    public function getPendienteRevision() {
        return (bool) $this->pendiente_revision;
    }

    public function getFacebook() {
        return $this->social_facebook;
    }

    public function getLinkedin() {
        return $this->social_linkedin;
    }

    public function setUsuario($usuario) {
        $this->usuario = $usuario;
        return $this;
    }

    public function setRoleId($rol_id, $save = true) {
        $this->rol_id = (int) $rol_id;
        if ($save === true) {
            $this->save();
        }
        return $this;
    }

    public function toArrayData() {
        $role = $this->getRole();
        $role = $role ? $role->toArrayData() : array();
        return array(
            'id' => $this->getId(),
            'usuario' => $this->getUsuario(),
            'ultimo_ingreso' => $this->getUltimoIngreso(),
            'ultima_modificacion' => $this->getUltimaModificacion(),
            'role' => $role,
        );
    }

    public function toArray() {
        $array = parent::toArray();
        $terapias = [];
        foreach ($this->getTiposMasajes() as /* @var $terapia Model_Row_TipoMasaje */ $terapia) {
            $terapias[] = $terapia->getId();
        }
        $array['terapias'] = $terapias;
        return $array;
    }

    public function __toString() {
        return $this->getUsuario();
    }

    public function getTextoTiposMasajes() {
        $masajes = [];
        foreach ($this->getTiposMasajes() as /* @var $masaje Model_Row_TipoMasaje */ $masaje) {
            $masajes[] = $masaje->getNombre();
        }
        return implode(', ', $masajes);
    }

    public function getPuntuacionPromedio() {
        return 4.5;
    }

    /**
     *
     * @param Zend_Date $fecha
     * @param string $hora
     */
    public function validarHoraTrabajo($fecha, $hora) {
        // Valido si tiene excepcion, devuelvo eso directamente
        $sql = Model_CalendariosExcepciones::getSingleton()
                ->select()
                ->where('DATE_FORMAT(fecha, "%Y%m%d") = ?', $fecha->toString('yMMdd'))
                ->where('hora = ?', $hora)
        ;
        $excepcion = $this->findParentRow('Model_CalendariosExcepciones', 'Excepciones', $sql);
        if ($excepcion != null) {
            return $excepcion->trabaja;
        }
        // En caso de que no tenga excepcion, busco en la hora segun el dia
        $sql = Model_CalendariosDias::getSingleton()
                ->select()
                ->where('dia = ?', strtolower($fecha->toString('EEE', 'en')))
                ->where('hora = ?', $hora)
        ;
        $item = $this->findParentRow('Model_CalendariosDias', 'HorasPorDia', $sql);
        // @todo Validar reservas
        return ($item != null);
    }

}
