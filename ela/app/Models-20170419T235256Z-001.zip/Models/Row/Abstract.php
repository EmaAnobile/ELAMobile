<?php

class Model_Row_Abstract extends Zend_Db_Table_Row_Abstract {

    public function __toString() {
        return sprintf('%s', $this->getId());
    }

    protected $_traducciones = array();
    protected $_init = false;
    protected $_idioma = APPLICATION_LANG;
    static protected $_cache = array();

    final public function getIdioma() {
        return explode('_', Zend_Registry::get('Zend_Translate')->getLocale());
    }

    public function addTraduccion($campo, $traduccion) {
        $idi = $this->getIdioma();
        $idi = $idi[0];
        if (!isset($this->_traducciones[$idi])) {
            $this->_traducciones[$idi] = array();
        }
        $this->_traducciones[$idi][$campo] = $traduccion;
        return $this;
    }

    public function addTraducciones($trads) {
        foreach ($trads as $campo => $trad) {
            $this->addTraduccion($campo, $trad);
        }
        return $this;
    }

    public function getTraduccion($campo, $idi = null) {
        if ($idi === null) {
            $idi = $this->_idioma;
        }

        return ($this->hasTraduccion($idi, $campo)) ?
                $this->_traducciones[$idi][$campo] : $this->{$campo};
    }

    public function hasTraduccion($idioma, $campo = null) {
        if ($campo === null) {
            return (isset($this->_traducciones[$idioma]));
        }
        return $this->hasTraduccion($idioma) && isset($this->_traducciones[$idioma][$campo]) && $this->_traducciones[$idioma][$campo] !== '';
    }

    public function setInit($param = true) {
        $this->_init = ($param === true) ? true : false;
        return $this;
    }

    public function arrayTraducido() {
        $arr = array();
        foreach ($this->toArray() as $campo => $valor) {
            $arr[$campo] = $this->getTraduccion($campo);
        }
        return $arr;
    }

    public function setupLocale($locale = null) {
        $lc = Zend_Registry::get('Zend_Translate')->getLocale();
        $idioma = ($locale) ? $locale : $lc;
        Zend_Registry::get('Zend_Translate')->setLocale($idioma);
        $this->setupTraduccion();
        $this->_idioma = $idioma;
        Zend_Registry::get('Zend_Translate')->setLocale($lc);
        return $this;
    }

    public function getCache($key) {
        $key = $this->getCacheKey($key);
        if (isset(self::$_cache[$key]))
            return self::$_cache[$key];

        return null;
    }

    public function setCache($key, $value) {
        $key = $this->getCacheKey($key);
        self::$_cache[$key] = $value;
        return $this;
    }

    public function getCacheKey($key) {
        return get_class($this) . '_' . spl_object_hash($this) . '_' . $key;
    }

    public function __call($method, array $args) {
        switch (substr($method, 0, 3)) {
            case 'get' :
                $key = $this->_underscore(substr($method, 3));
                return $this->__get($key);
            case 'set' :
                $key = $this->_underscore(substr($method, 3));
                $this->__set($key, isset($args[0]) ? $args[0] : null);
                return $this;
            case 'uns' :
                $key = $this->_underscore(substr($method, 3));
                $this->__unset($key);
                return $this;
            case 'has' :
                $key = $this->_underscore(substr($method, 3));
                return $this->__isset($key);
        }
        throw new Exception("Invalid method " . get_class($this) . "::" . $method . "(" . print_r($args, 1) . ")");
    }

    protected function _underscore($name) {
        return strtolower(preg_replace('/(.)([A-Z])/', "$1_$2", $name));
    }

}
