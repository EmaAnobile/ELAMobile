<?php

class Model_Usuarios extends Model_SetupAbstract {

    protected $_rowClass = 'Model_Row_Usuario';
    protected $_rowsetClass = 'Model_Rowset_Usuarios';
    protected $_name = 'usuarios';
    protected $_dependentTables = array('Model_Roles');
    protected $_referenceMap = array(
        'Role' => array(
            'columns' => array('rol_id'),
            'refTableClass' => 'Model_Roles',
            'refColumns' => array('id')
        ),
        'Distrito' => array(
            'columns' => array('distrito_id'),
            'refTableClass' => 'Model_Distritos',
            'refColumns' => array('id')
        ),
        'Excepciones' => array(
            'columns' => array('id'),
            'refTableClass' => 'Model_CalendariosExcepciones',
            'refColumns' => array('usuario_id')
        ),
        'HorasPorDia' => array(
            'columns' => array('id'),
            'refTableClass' => 'Model_CalendariosDias',
            'refColumns' => array('usuario_id')
        ),
    );

    public function fetchAllByRol($rol, $incluirPendietes = false) {
        $cachekey = 'by_rol_' . $rol;
        if (!$this->getCache($cachekey)) {
            $dbRol = new Model_Roles();

            $rol = $dbRol->fetchRow(array('nombre = ?' => $rol));
            $sql = $this->select()->where('activo = ?', 1);

            if ($incluirPendietes === false) {
                $sql->where('pendiente_revision = 0');
            } else {
                $sql->order(['pendiente_revision DESC', 'nombre']);
            }

            $rows = $rol->findDependentRowset('Model_Usuarios', null, $sql);
            $this->setCache($cachekey, $rows);
        }
        return $this->getCache($cachekey);
    }

    public function fetchTerapeutasPorDistrito($distrito_id) {
        $cachekey = 'terapeutas_by_distrito_' . $distrito_id;
        if (!$this->getCache($cachekey)) {
            $dbRol = new Model_Roles();

            $rol = $dbRol->fetchRow(array('nombre = ?' => Model_Roles::ROL_TERAPEUTA));
            $sql = $this->select()
                    ->where('activo = ?', 1)
                    ->where('distrito_id = ?', $distrito_id);

            $rows = $rol->findDependentRowset('Model_Usuarios', null, $sql);
            $this->setCache($cachekey, $rows);
        }
        return $this->getCache($cachekey);
    }

    public static function existe($email, $id = 0) {
        if ($id == 0) {
            return self::getSingleton()->fetchRow(['email = ?' => $email]) != null;
        }

        return self::getSingleton()->fetchRow(['email = ?' => $email, 'id != ?' => $id]) != null;
    }

}
