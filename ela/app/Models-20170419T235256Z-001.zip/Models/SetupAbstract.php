<?php

abstract class Model_SetupAbstract extends Zend_Db_Table_Abstract {

    static $_instances = array();
    static protected $_cache = array();
    protected $_prefix = '';

    /**
     *
     * @return Model_SetupAbstract
     */
    final public static function getSingleton() {
        $class = get_called_class();

        if (!isset(self::$_instances[$class])) {
            self::$_instances[$class] = new $class();
        }

        return self::$_instances[$class];
    }

    public function fetchObj($rows) {
        try {
            $data = array(
                'table' => $this,
                'data' => $rows,
                'readOnly' => false,
                'rowClass' => $this->_rowClass,
                'stored' => true
            );

            return new $this->_rowsetClass($data);
        } catch (Exception $e) {
            $this->mail($e);
        }
    }

    public function getIdioma() {
        return explode('_', Zend_Registry::get('Zend_Translate')->getLocale());
    }

    public function getName() {
        return $this->_name;
    }

    public function __toString() {
        return $this->getName();
    }

    protected function _setupTableName() {
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $cfgdb = $db->getConfig();
        $this->_prefix = $cfgdb['prefix'];

        $this->_name = $this->_prefix . $this->_name;
    }

    public function foundRows() {
        $t = $this->getDb()->query('SELECT FOUND_ROWS() as total')->fetch();
        return $t['total'];
    }

    public function mail(Exception $e) {
        $html = <<<HTML
        <h3>{$e->getMessage()}</h3>
        <pre>{$e->getTraceAsString()}</pre>
HTML;

        $mail = new Service_Mail();
        $mail->setSubject('[Baillyweb] Error')
                ->setFrom('manuelcanepa@gmail.com')
                ->setTo('manuelcanepa@gmail.com')
                ->setBodyHtml($html)
                ->send()
        ;
    }

    public function parseQuery($query) {
        $query = str_replace('{{prefix}}', $this->_prefix, $query);
        $query = trim($query);
        return $query;
    }

    public static function compareVersion($version, $installed) {
        $version = strtolower($version);
        $version = preg_replace('/(\d)pr(\d?)/', '$1a$2', $version);
        return version_compare($version, strtolower($installed));
    }

    public function getCache($key) {
        $key = $this->getCacheKey($key);
        if (isset(self::$_cache[$key]))
            return self::$_cache[$key];

        return null;
    }

    public function setCache($key, $value) {
        $key = $this->getCacheKey($key);
        self::$_cache[$key] = $value;
        return $this;
    }

    public function getCacheKey($key) {
        return get_class($this) . '_' . $key;
    }

    public function callStoredProcedure($name, $params) {
        foreach ($params as $val) {
            if ($val instanceof Zend_Db_Expr) {
                $vals[] = $val->__toString();
            } else {
                $vals[] = '?';
            }
        }

        return $this->getAdapter()->query('CALL ' . $this->_prefix . $name . ' (' . implode(', ', $vals) . ')', $params);
    }

}
